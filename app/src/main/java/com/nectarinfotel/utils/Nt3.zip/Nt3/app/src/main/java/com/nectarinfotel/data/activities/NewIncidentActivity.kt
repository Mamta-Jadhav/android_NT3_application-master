package com.nectarinfotel.data.activities

import android.R
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.nectarinfotel.ui.login.LoginActivity
import kotlinx.android.synthetic.main.activity_dashboard.*
import kotlinx.android.synthetic.main.activity_detail_page.*
import kotlinx.android.synthetic.main.new_incident_layout.*
import java.util.*

class NewIncidentActivity : AppCompatActivity() , AdapterView.OnItemSelectedListener {
    // Initialize a new array with elements
    val colors = arrayOf(
        "Nilesh","Apeksha","Rekha","Sonali","Rashmi",
        "Priya","GreenYellow"
    )
    val area_spinner = arrayOf(
        "Hadapsar","Magarpatta","Goa","India","Pune"
    )
    val services_spinner = arrayOf(
        "alarm service"
        )
    var area: String? =null
    var services: String? =null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.nectarinfotel.R.layout.new_incident_layout)
        setSupportActionBar(toolbar_incident)
        //set data into adapter for area
        initAreaSpinnerResources()

        //set data into adapter for services
        initserviceSpinnerResources()

       //language conversion
        if(LoginActivity.language.equals("Portuguese"))
        {
            val config =resources.configuration
            val locale = Locale("pt")
            Locale.setDefault(locale)
            config.locale = locale
            resources.updateConfiguration(config, resources.displayMetrics)
            incident_title_text.setText(resources.getString(com.nectarinfotel.R.string.title))
            incident_area_text.setText(resources.getString(com.nectarinfotel.R.string.select_area))
            incident_services_text.setText(resources.getString(com.nectarinfotel.R.string.select_services))
            incident_reported_by_text.setText(resources.getString(com.nectarinfotel.R.string.Caller))
            create_incident.setText(resources.getString(com.nectarinfotel.R.string.create))
        }
        else
        {
            val config = resources.configuration
            val locale = Locale("en")
            Locale.setDefault(locale)
            config.locale = locale
            resources.updateConfiguration(config, resources.displayMetrics)
            incident_title_text.setText(resources.getString(com.nectarinfotel.R.string.title))
            incident_area_text.setText(resources.getString(com.nectarinfotel.R.string.select_area))
            incident_services_text.setText(resources.getString(com.nectarinfotel.R.string.select_services))
            incident_reported_by_text.setText(resources.getString(com.nectarinfotel.R.string.Caller))
            create_incident.setText(resources.getString(com.nectarinfotel.R.string.create))
        }
        // Initialize a new array adapter object
        val adapter = ArrayAdapter<String>(
            this, // Context
            R.layout.simple_dropdown_item_1line, // Layout
            colors // Array
        )

        // Set the AutoCompleteTextView adapter
        incident_reported_by.setAdapter(adapter)


        // Auto complete threshold
        // The minimum number of characters to type to show the drop down
        incident_reported_by.threshold = 1


        // Set an item click listener for auto complete text view
        incident_reported_by.onItemClickListener = AdapterView.OnItemClickListener{
                parent,view,position,id->
            val selectedItem = parent.getItemAtPosition(position).toString()
            // Display the clicked item using toast
            Toast.makeText(applicationContext,"Selected : $selectedItem", Toast.LENGTH_SHORT).show()
        }
        // Set a focus change listener for auto complete text view
        incident_reported_by.onFocusChangeListener = View.OnFocusChangeListener{
                view, b ->
            if(b){
                // Display the suggestion dropdown on focus
                incident_reported_by.showDropDown()
            }
        }
        // Set a dismiss listener for auto complete text view
        incident_reported_by.setOnDismissListener {
            Toast.makeText(applicationContext,"Suggestion closed.",Toast.LENGTH_SHORT).show()
        }
        backImageView_incident.setOnClickListener {
            finish()
        }
        create_incident.setOnClickListener {
          if(incident_title.text.toString().length==0)
          {
              Toast.makeText(applicationContext,resources.getString(com.nectarinfotel.R.string.enter_title),Toast.LENGTH_SHORT).show()
          }else if (area==null)
          {
              Toast.makeText(applicationContext,resources.getString(com.nectarinfotel.R.string.enter_area),Toast.LENGTH_SHORT).show()
          }
          else if (services==null)
          {
              Toast.makeText(applicationContext,resources.getString(com.nectarinfotel.R.string.enter_services),Toast.LENGTH_SHORT).show()
          }
          else if (incident_reported_by.text.toString().length==0)
          {
              Toast.makeText(applicationContext,resources.getString(com.nectarinfotel.R.string.enter_caller),Toast.LENGTH_SHORT).show()
          }
            else
          {

          }
        }
    }

    private fun initserviceSpinnerResources() {
        incident_area.onItemSelectedListener = this

        //Creating the ArrayAdapter instance having the country list
        val aa = ArrayAdapter(this, android.R.layout.simple_spinner_item, area_spinner)
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        //Setting the ArrayAdapter data on the Spinner
        incident_area.adapter = aa
    }

    private fun initAreaSpinnerResources() {
        incident_services.onItemSelectedListener = this

        //Creating the ArrayAdapter instance having the country list

        val aa = ArrayAdapter(this, android.R.layout.simple_spinner_item, services_spinner)
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        //Setting the ArrayAdapter data on the Spinner
        incident_services.adapter = aa
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {

    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

    }
}