package com.nectarinfotel.retrofit;

import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetroAPIInterface {

    @GET("https://nt3.nectarinfotel.com/webservices/login.php")
    Call<JsonObject> callLoginAPI(@Query("auth_user") String username,
                                  @Query("auth_pwd") String password,
                                  @Query("device_token") String device_token);

    @GET("https://nt3.nectarinfotel.com/webservices/dashboard.php")
    Call<JsonObject> callDashboardAPI(@Query("category") String category,
                                      @Query("subcategory") String subcategory,
                                      @Query("userid") String userid);

    @GET("https://nt3.nectarinfotel.com/webservices/ticket_list.php")
    Call<JsonObject> callStatusDetailAPI(@Query("category") int category,
                                         @Query("subcategory") String subcategory,
                                         @Query("status") String status,
                                         @Query("userid") String userid,
                                         @Query("urgency") int urgency);

    @GET("https://nt3.nectarinfotel.com/webservices/ticket_list.php")
    Call<JsonObject> callAgentDetailAPI(@Query("category") int category,
                                        @Query("subcategory") String subcategory,
                                        @Query("agent") String agent,
                                        @Query("userid") String userid,
                                        @Query("urgency") int urgency);

    @GET("https://nt3.nectarinfotel.com/webservices/ticket_list.php")
    Call<JsonObject> callDepartmentDetailAPI(@Query("category") int category,
                                             @Query("subcategory") String subcategory,
                                             @Query("department") String department,
                                             @Query("userid") String userid,
                                             @Query("urgency") int urgency);

    @GET("https://nt3.nectarinfotel.com/webservices/ticket_info.php")
    Call<JsonObject> callTicketDetailAPI(@Query("category") int category,
                                             @Query("ticketid") String subcategory,
                                             @Query("userid") String department);

}
//https://nt3.nectarinfotel.com/webservices