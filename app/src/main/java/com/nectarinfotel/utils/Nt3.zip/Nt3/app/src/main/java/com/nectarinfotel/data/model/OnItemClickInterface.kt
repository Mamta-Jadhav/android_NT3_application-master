package com.nectarinfotel.data.model

interface OnItemClickInterface {
    fun OnClick(status: String, status1: String)
}