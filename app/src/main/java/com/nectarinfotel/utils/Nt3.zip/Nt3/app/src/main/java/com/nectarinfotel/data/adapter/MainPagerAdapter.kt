package com.nectarinfotel.data.adapter



import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.PagerAdapter
import com.nectarinfotel.R

/** @author Aidan Follestad (afollestad) */
class MainPagerAdapter : PagerAdapter() {

    override fun instantiateItem(
        collection: ViewGroup,
        position: Int
    ): Any {
        var resId = 0
        when (position) {
            0 -> resId = R.id.pageOne
            1 -> resId = R.id.pageTwo

        }
        return collection.findViewById(resId)
    }

    override fun isViewFromObject(
        arg0: View,
        arg1: Any
    ) = arg0 === arg1 as View

    override fun getCount() = 4

    override fun getPageTitle(position: Int) = when (position) {
        0 -> "One"
        1 -> "Two"

        else -> null
    }

    override fun destroyItem(
        container: ViewGroup,
        position: Int,
        arg1: Any
    ) = Unit
}