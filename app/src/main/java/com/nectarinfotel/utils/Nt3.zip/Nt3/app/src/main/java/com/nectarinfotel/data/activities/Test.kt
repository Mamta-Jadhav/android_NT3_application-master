package com.nectarinfotel.data.activities

import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity

import com.nectarinfotel.R
import com.nectarinfotel.data.adapter.MainPagerAdapter
import com.nectarinfotel.utils.isColorLight
import com.nectarinfotel.utils.onPageSelected
import kotlinx.android.synthetic.main.layout.*


class Test  : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout)

        pager.adapter = MainPagerAdapter()
        pager.offscreenPageLimit = 3
        dots.attachViewPager(pager)

        pager.onPageSelected {
            val colorRes = when (it) {
                0 -> R.color.colorPrimary
                1 -> R.color.red
                2 -> R.color.white
                else -> R.color.colorPrimaryDark
            }
            val color = ContextCompat.getColor(this, colorRes)
            frame.setBackgroundColor(color)
            dots.setDotTintRes(if (color.isColorLight()) R.color.red else R.color.white)
        }
    }
}