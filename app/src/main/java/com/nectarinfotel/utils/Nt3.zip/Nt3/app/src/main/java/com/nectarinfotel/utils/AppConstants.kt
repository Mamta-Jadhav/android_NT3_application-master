package com.nectarinfotel.utils

class AppConstants {

    companion object{
        @JvmStatic
        public var BASE_URL : String? = "https://nt3test.nectarinfotel.com/webservices/"
        val Username = "username"
        val Password = "password"
        val TokenID = "tokenid"
    }

}